import React from "react";

const AppStoreBanner = () => {
  return <div>AppStoreBanner</div>;
};

export default AppStoreBanner;
